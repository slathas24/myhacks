package com.scb.retail.policy;

import com.scb.retail.dto.PolicyApplication;
import com.scb.retail.policy.exception.PolicyException;

import java.time.LocalDate;

public class VehicleInsurancePolicy extends Policy{
    private int vehicletype;

    public VehicleInsurancePolicy(String policynumber, String policytype, String description, int basepremium, int policyValue, int policyduration, LocalDate policystartdate, LocalDate policymaturitydate, int cehicletype) throws PolicyException {
        super(policynumber, policytype, description, basepremium, policyValue, policyduration, policystartdate, policymaturitydate);
        this.vehicletype = cehicletype;
    }

    public VehicleInsurancePolicy(int cehicletype) {
        this.vehicletype = cehicletype;
    }

    public void setVehicletype(int cehicletype) {
        this.vehicletype = cehicletype;
    }
    public int getVehicletype() {
        return vehicletype;
    }
    public VehicleInsurancePolicy() {
        super();
    }
    @Override
   public void calculatePremium(Object o) {
        System.out.println("Inside Vehicle Insurance caluclate Premium");
        PolicyApplication policyApp = (PolicyApplication) o;
        int basePremium=0;
        if (policyApp.vehicletype == 2) {
            basePremium = 700;
        } else if (policyApp.vehicletype == 3) {
                basePremium=900;
            } else if (policyApp.vehicletype == 4) {
            basePremium = 1000;
        }
        if (policyApp.vehicleage < 5) {
            basePremium += (basePremium * .2);
        } else if (policyApp.vehicleage < 10) {
            basePremium += (basePremium * .25);
        } else if (policyApp.vehicleage < 15) {
            basePremium += (basePremium * .35);

        }
        this.setBasepremium(basePremium);
    }
}
