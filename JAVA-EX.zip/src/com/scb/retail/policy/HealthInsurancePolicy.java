package com.scb.retail.policy;

import com.scb.retail.dto.PolicyApplication;
import com.scb.retail.policy.exception.PolicyException;

import java.time.LocalDate;

public class HealthInsurancePolicy  extends Policy{
    private boolean dentalcoverage;
    private boolean visioncoverage;

    public HealthInsurancePolicy(String policynumber, String policytype, String description, int basepremium, int policyValue, int policyduration, LocalDate policystartdate, LocalDate policymaturitydate, boolean dentalcoverage, boolean visioncoverage) throws PolicyException {

        super(policynumber, policytype, description, basepremium, policyValue, policyduration, policystartdate, policymaturitydate);
        if  (dentalcoverage == true  && visioncoverage == true  && policyValue <= 120000) {
            throw new PolicyException("Policy Value should be greater than 120000 for dental and vision coverage");
        }

        this.dentalcoverage = dentalcoverage;
        this.visioncoverage = visioncoverage;
    }

    public HealthInsurancePolicy() {
    }

    @Override
   public  void  calculatePremium(Object o) {
       System.out.println("Inside Health Insurance caluclate Premium");
       PolicyApplication policyApp = (PolicyApplication) o;

       int basePremium=800;
       if (policyApp.age < 25 ) {
           basePremium += (basePremium * .2);
       } else if (policyApp.age < 50){
           basePremium += (basePremium * .25);
       } else if (policyApp.age < 70 ) {
           basePremium += (basePremium * .35);
       }
     if (dentalcoverage) {
         basePremium += (basePremium * .30);
     }
     if (visioncoverage) {
         basePremium += (basePremium * .20);
     }
        this.setBasepremium(basePremium);

    }

    public boolean isDentalcoverage() {
        return dentalcoverage;
    }

    public void setDentalcoverage(boolean dentalcoverage) {
        this.dentalcoverage = dentalcoverage;
    }

    public boolean isVisioncoverage() {
        return visioncoverage;
    }

    public void setVisioncoverage(boolean visioncoverage) {
        this.visioncoverage = visioncoverage;
    }
}
