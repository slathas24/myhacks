package com.scb.retail.policy.exception;

public class PolicyException  extends Exception {
    public PolicyException(String message) {
        super(message);
    }
}
