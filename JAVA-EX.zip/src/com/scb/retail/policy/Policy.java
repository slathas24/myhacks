package com.scb.retail.policy;

import com.scb.retail.policy.exception.PolicyException;

import java.time.LocalDate;

public abstract class Policy {
    private  String policynumber ;
    private  String policytype;
    private String Description ;
    private int  basepremium;
    private int policyValue ;
    private int policyduration;
    private LocalDate policystartdate;
    private LocalDate  policymaturitydate;

    public Policy(String policynumber, String policytype, String description, int basepremium, int policyValue, int policyduration, LocalDate policystartdate, LocalDate policymaturitydate) throws PolicyException {
        if (policyValue < 100000) {
            throw new PolicyException("Policy Value should be greater than 100000");
        }
        this.policynumber = policynumber;
        this.policytype = policytype;
        Description = description;
        this.basepremium = basepremium;
        this.policyValue = policyValue;
        this.policyduration = policyduration;
        this.policystartdate = policystartdate;
        this.policymaturitydate = policymaturitydate;
    }

    public Policy() {
    }

    public String getPolicynumber() {
        return policynumber;
    }

    public void setPolicynumber(String policynumber) {
        this.policynumber = policynumber;
    }

    public String getPolicytype() {
        return policytype;
    }

    public void setPolicytype(String policytype) {
        this.policytype = policytype;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public int getBasepremium() {
        return basepremium;
    }

    public void setBasepremium(int basepremium) {
        this.basepremium = basepremium;
    }

    public int getPolicyValue() {
        return policyValue;
    }

    public void setPolicyValue(int policyValue) {
        this.policyValue = policyValue;
    }

    public int getPolicyduration() {
        return policyduration;
    }

    public void setPolicyduration(int policyduration) {
        this.policyduration = policyduration;
    }

    public LocalDate getPolicystartdate() {
        return policystartdate;
    }

    public void setPolicystartdate(LocalDate policystartdate) {
        this.policystartdate = policystartdate;
    }

    public LocalDate getPolicymaturitydate() {
        return policymaturitydate;
    }

    public void setPolicymaturitydate(LocalDate policymaturitydate) {
        this.policymaturitydate = policymaturitydate;
    }

    public abstract  void  calculatePremium(Object o);
}
