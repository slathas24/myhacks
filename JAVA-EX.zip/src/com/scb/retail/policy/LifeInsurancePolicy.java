package com.scb.retail.policy;

import com.scb.retail.dto.PolicyApplication;
import com.scb.retail.policy.exception.PolicyException;

import java.time.LocalDate;

public class LifeInsurancePolicy extends Policy{
  private   int term ;

  public LifeInsurancePolicy() {
      super();
      term=0;
  }

    @Override
   public  void calculatePremium(Object o) {
      System.out.println("Inside Life Insurance caluclate Premium");
     PolicyApplication lpolicy =  (PolicyApplication)  o;
      int basePremium=1000;
      if (lpolicy.term < 10 ) {
          basePremium += (basePremium * .2);
        } else {
          basePremium += (basePremium * .25);
      }
      if (lpolicy.policyValue > 500000) {
          basePremium += (basePremium * .30);
      }
     this.setBasepremium(basePremium);
    }

    public LifeInsurancePolicy(String policynumber, String policytype, String description, int basepremium, int policyValue, int policyduration, LocalDate policystartdate, LocalDate policymaturitydate, int term) throws PolicyException {
        super(policynumber, policytype, description, basepremium, policyValue, policyduration, policystartdate, policymaturitydate);
        if  (term < 4) {
            throw new PolicyException("Term should be greater than 4");
        }
        this.term = term;
    }



    public int getTerm() {
        return term;
    }

    public void setTerm(int term) throws PolicyException {
        if  (term < 4) {
            throw new PolicyException("Term should be greater than 4");
        }
        this.term = term;
    }

}
