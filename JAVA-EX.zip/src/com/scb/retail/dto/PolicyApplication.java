package com.scb.retail.dto;

public class PolicyApplication {
    public String policytype;
    public int policyValue;
    public int policyduration;
    public int term;
    public int age;
    public boolean visioncoverage;
    public boolean dentalcoverage;
    public int vehicletype;
    public int vehicleage;

}
