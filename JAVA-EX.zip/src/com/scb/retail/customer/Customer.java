package com.scb.retail.customer;

import com.scb.retail.policy.Policy;

import java.util.ArrayList;
import java.util.List;

public class Customer {
    String custiid;
    String custname;
    int age;
    List policylist = new ArrayList<Policy>();

    public Customer(String custiid, String custname, int age, List policy) {
        this.custiid = custiid;
        this.custname = custname;
        this.age = age;
        this.policylist = policy;
    }

    public Customer(String custiid, String custname, int age) {
        this.custiid = custiid;
        this.custname = custname;
        this.age = age;

    }

    public String getCustiid() {
        return custiid;
    }

    public void setCustiid(String custiid) {
        this.custiid = custiid;
    }

    public String getCustname() {
        return custname;
    }

    public void setCustname(String custname) {
        this.custname = custname;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public List<Policy> getPolicy() {
        return policylist;
    }

    public void setPolicy(List<Policy> policy) {
        this.policylist = policy;
    }

    public void addPolicy(Policy policy) {
        policylist.add(policy);

    }
}