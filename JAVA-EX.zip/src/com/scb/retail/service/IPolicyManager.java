package com.scb.retail.service;

import com.scb.retail.customer.Customer;
import com.scb.retail.dto.PolicyApplication;
import com.scb.retail.policy.HealthInsurancePolicy;
import com.scb.retail.policy.LifeInsurancePolicy;
import com.scb.retail.policy.Policy;
import com.scb.retail.policy.VehicleInsurancePolicy;
import com.scb.retail.policy.exception.PolicyException;

public interface IPolicyManager {
    public void allocatePolicy(Customer cust, PolicyApplication policyapp) throws PolicyException ;
   public  int getPolicyCount(String policytype);


    }


