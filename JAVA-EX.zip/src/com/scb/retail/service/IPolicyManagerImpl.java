package com.scb.retail.service;

import com.scb.retail.customer.Customer;
import com.scb.retail.dto.PolicyApplication;
import com.scb.retail.policy.HealthInsurancePolicy;
import com.scb.retail.policy.LifeInsurancePolicy;
import com.scb.retail.policy.Policy;
import com.scb.retail.policy.VehicleInsurancePolicy;
import com.scb.retail.policy.exception.PolicyException;

import java.time.LocalDate;

public class IPolicyManagerImpl  implements IPolicyManager {
    private Policy policy = null;
    int lifepolicycount = 0;
    int vehiclepolicycount = 0;
    int healthpolicycount = 0;

    @Override
    public void allocatePolicy(Customer cust, PolicyApplication policyapp) throws PolicyException {
        if (policyapp.policytype.equals("Health")) {
            policy = new HealthInsurancePolicy();
            healthpolicycount++;
        } else if (policyapp.policytype.equals("Vehicle")) {
            policy = new VehicleInsurancePolicy();
            vehiclepolicycount++;
        } else  if (policyapp.policytype.equals("Life")){
            policy = new LifeInsurancePolicy();
            lifepolicycount++;
        }

        policy.calculatePremium(policyapp);
        //policy.setBasepremium(premium);
        policy.setPolicystartdate(LocalDate.now());
        policy.setPolicymaturitydate(LocalDate.now().plusYears(policy.getPolicyduration()));
        policy.setPolicynumber(generatePoliyNumber(policyapp.policytype));
        cust.addPolicy(policy);
    }
    private String generatePoliyNumber(String policytype) {
        String prefix = "";
        if (policytype.equals("Health")) {
            prefix = "HLT";
        } else if (policytype.equals("Vehicle")) {
            prefix = "VEH";
        } else if (policytype.equals("Life")) {
            prefix = "LFE";
        }
        return prefix + System.currentTimeMillis();
    }


    @Override
    public int getPolicyCount(String policytype) {
        int x=0;
        if (policytype.equals("Health")) {
           x=healthpolicycount;
        } else if (policytype.equals("Vehicle")){
             x=vehiclepolicycount;
        } else if (policytype.equals("Life")){
        x=lifepolicycount;
        }
        return x;
    }
}


