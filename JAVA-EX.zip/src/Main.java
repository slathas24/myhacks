import com.scb.retail.customer.Customer;
import com.scb.retail.dto.PolicyApplication;
import com.scb.retail.policy.HealthInsurancePolicy;
import com.scb.retail.policy.LifeInsurancePolicy;
import com.scb.retail.policy.Policy;
import com.scb.retail.policy.VehicleInsurancePolicy;
import com.scb.retail.service.IPolicyManager;
import com.scb.retail.service.IPolicyManagerImpl;

import java.util.HashMap;
import java.util.List;

public class Main {
    public static void main(String[] args)  throws Exception {

   Customer cust=new Customer("1234","John",25);
        PolicyApplication policyapp=new PolicyApplication();
        policyapp.vehicleage=0;
        policyapp.vehicletype=0;
        policyapp.policytype="Life";
        policyapp.policyValue=120000;
        policyapp.age=25;
        policyapp.dentalcoverage=false;
        policyapp.visioncoverage=false;

        IPolicyManager ipm=new IPolicyManagerImpl();
        ipm.allocatePolicy(cust,policyapp);
       Policy pl= cust.getPolicy().get(0);
        System.out.println(pl.getPolicynumber());

          //  PolicyApplication policyapp1=new PolicyApplication("1235","Life","Life Insurance",1000,120000,10,null,null,10);




     /*
        HashMap<String,Policy> policymap=new HashMap<String,Policy>();
        policymap.put("1234",new LifeInsurancePolicy("1234", "Life", "Life Insurance", 1000, 120000, 10, null, null, 10));
        policymap.put("1235",new LifeInsurancePolicy("1235", "Life", "Life Insurance", 1000, 120000, 10, null, null, 10));
        policymap.put("1236",new HealthInsurancePolicy("1236", "Health", "Health Insurance", 1000, 130000, 10, null, null, true, true));
        policymap.put("1237",new VehicleInsurancePolicy("1237", "Vehicle", "Vehicle Insurance", 1000, 120000, 10, null, null, 1));
        policymap.put("1238",new HealthInsurancePolicy("1238", "Health", "Health Insurance", 1000, 140000, 10, null, null, true, true));

        for (Policy p : policymap.values()) {
            p.calculatePremium("abcd");
        }

        Policy[] policyarr = new Policy[5];

        policyarr[0] = new LifeInsurancePolicy("1234", "Life", "Life Insurance", 1000, 120000, 10, null, null, 10);
        policyarr[1] = new LifeInsurancePolicy("1235", "Life", "Life Insurance", 1000, 120000, 10, null, null, 10);

        policyarr[2] = new HealthInsurancePolicy("1236", "Health", "Health Insurance", 1000, 130000, 10, null, null, true, true);
        policyarr[3] = new VehicleInsurancePolicy("1237", "Vehicle", "Vehicle Insurance", 1000, 120000, 10, null, null, 1);
        policyarr[4] = new HealthInsurancePolicy("1238", "Health", "Health Insurance", 1000, 140000, 10, null, null, true, true);

        for (Policy p : policyarr) {
            p.calculatePremium("abcd");
        }
        */

    }
}