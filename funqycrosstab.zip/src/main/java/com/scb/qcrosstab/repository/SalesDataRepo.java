package com.scb.qcrosstab.repository;

import com.scb.qcrosstab.entity.SalesData;
import io.quarkus.hibernate.orm.PersistenceUnit;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;


import java.util.List;
@ApplicationScoped
public class SalesDataRepo implements PanacheRepository<SalesData> {

    //@PersistenceContext
   //@PersistenceUnit("default")
   @Inject
    EntityManager em;
    public List<Object[]> getCrossTabData() {
        String nativeQuery = """
            SELECT
                salesmanid AS salesman,
               month AS Month,
                SUM(sales) AS sales
            FROM
                salesdata
            GROUP BY
                salesmanid, month 
            ORDER BY
                salesmanid, month
        """;

        return em.createNativeQuery(nativeQuery).getResultList();
    }


}


