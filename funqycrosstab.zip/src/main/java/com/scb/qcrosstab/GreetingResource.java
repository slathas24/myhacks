/*
package com.scb.qcrosstab;

import com.scb.qcrosstab.service.SalesDataService;
import jakarta.inject.Inject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

import java.util.List;
import java.util.Map;

@Path("/crosstab")
public class GreetingResource {

    @Inject
    SalesDataService salesService;

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String hello() {
        return "Hello from RESTEasy Reactive";
    }




        @GET
        @Path("/crosstab/dynamic")
        @Produces(MediaType.APPLICATION_JSON)

        public List<Map<String, Object>> getDynamicCrossTab() {
            return salesService.getDynamicCrossTabData();
        }
    }
*/