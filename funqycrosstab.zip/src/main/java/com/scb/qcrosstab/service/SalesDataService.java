package com.scb.qcrosstab.service;

import com.scb.qcrosstab.repository.SalesDataRepo;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@ApplicationScoped
public class SalesDataService {
    @Inject
    SalesDataRepo salesRepository;

    public List<Map<String, Object>> getDynamicCrossTabData() {
        List<Object[]> rawData = salesRepository.getCrossTabData();
        Map<String, Map<String, Long>> customerSalesMap = new LinkedHashMap<>();
        for (Object[] row : rawData) {
            String salesman = (String) row[0];
            String month = (String) row[1];
            Long sales = (Long) row[2];
            customerSalesMap
                    .computeIfAbsent(salesman, k -> new LinkedHashMap<>())
                    .put(month, sales);
        }
        List<Map<String, Object>> result = new ArrayList<>();
        for (Map.Entry<String, Map<String, Long>> entry : customerSalesMap.entrySet()) {
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("salesman", entry.getKey());
            row.putAll(entry.getValue()); // Add monthly sales as columns
            result.add(row);
        }
        return result;
    }
}