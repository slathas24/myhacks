package com.scb.qcrosstab;

import com.scb.qcrosstab.service.SalesDataService;
import io.quarkus.funqy.Funq;
import jakarta.inject.Inject;

import java.util.List;
import java.util.Map;

public class CrossTabFunq {

    @Inject
    SalesDataService salesService;

    @Funq("crosstab")
    public List<Map<String, Object>> getDynamicCrossTab() {
        return salesService.getDynamicCrossTabData();
    }

}
