package com.scb.qcrosstab.dto;

import java.util.Map;

public class SalesDTO {
    private String salesmanid;
    private Map<String, Long> monthlySales;

    public String getSalesmanid() {
        return salesmanid;
    }

    public void setSalesmanid(String salesmanid) {
        this.salesmanid = salesmanid;
    }

    public Map<String, Long> getMonthlySales() {
        return monthlySales;
    }

    public void setMonthlySales(Map<String, Long> monthlySales) {
        this.monthlySales = monthlySales;
    }

    public SalesDTO(String salesmanid, Map<String, Long> monthlySales) {
        this.salesmanid = salesmanid;
        this.monthlySales = monthlySales;
    }

    public SalesDTO() {
    }
}
