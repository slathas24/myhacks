package com.scb.qcrosstab.entity;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name= "salesdata")
public class SalesData extends PanacheEntityBase {
    @Id
    public String salesmanid;
    public String month;
    public Long sales;
}
